<?php

namespace One97\Paytm\Block\Info;

class Paytm extends \Magento\Payment\Block\Info
{
    // protected $_template = 'One97_Paytm::info/paytm.phtml';
}
